/* ========================================
   GLOBAL JAVASCRIPT UTILITIES
   ======================================== */

// Dark Mode Toggle
const themeToggle = document.querySelector('.theme-toggle');
const htmlElement = document.documentElement;

// Check localStorage for theme preference
function initTheme() {
  const savedTheme = localStorage.getItem('theme') || 'light';
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-mode');
    themeToggle && (themeToggle.textContent = '☀️');
  }
}

themeToggle && themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  const isDark = document.body.classList.contains('dark-mode');
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  themeToggle.textContent = isDark ? '☀️' : '🌙';
});

// Mobile Menu Toggle
const navbarToggle = document.querySelector('.navbar-toggle');
const navMenu = document.querySelector('nav ul');

navbarToggle && navbarToggle.addEventListener('click', () => {
  navMenu.classList.toggle('hidden');
});

// Close menu when link clicked
document.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', () => {
    navMenu && navMenu.classList.add('hidden');
  });
});

// Back to Top Button
const backToTopBtn = document.querySelector('.back-to-top');

window.addEventListener('scroll', () => {
  if (window.scrollY > 300) {
    backToTopBtn && backToTopBtn.classList.add('show');
  } else {
    backToTopBtn && backToTopBtn.classList.remove('show');
  }
});

backToTopBtn && backToTopBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Animated Counter
function animateCounter(element, target, duration = 2000) {
  const start = 0;
  const startTime = Date.now();
  
  const updateCount = () => {
    const elapsed = Date.now() - startTime;
    const progress = elapsed / duration;
    
    if (progress < 1) {
      const current = Math.floor(start + (target - start) * progress);
      element.textContent = current.toLocaleString();
      requestAnimationFrame(updateCount);
    } else {
      element.textContent = target.toLocaleString();
    }
  };
  
  updateCount();
}

// Intersection Observer for animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      // Trigger counter animation
      if (entry.target.classList.contains('stat-number')) {
        const target = parseInt(entry.target.dataset.target) || 0;
        animateCounter(entry.target, target);
        observer.unobserve(entry.target);
      }
      
      // Fade in animation
      entry.target.style.animation = 'slideInUp 0.6s ease-out forwards';
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

// Observe all stat numbers and cards on page load
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.stat-number, .card, .feature-card').forEach(el => {
    observer.observe(el);
  });
  
  // Hide loading screen
  const loadingScreen = document.querySelector('.loading-screen');
  if (loadingScreen) {
    setTimeout(() => {
      loadingScreen.classList.add('hidden');
    }, 500);
  }
});

// Create Charts using SVG & Canvas

// Bar Chart (SVG)
function createBarChart(canvasId, labels, data, maxValue = null) {
  const container = document.getElementById(canvasId);
  if (!container) return;
  
  const max = maxValue || Math.max(...data);
  const width = container.offsetWidth;
  const height = 300;
  const barWidth = width / labels.length;
  const padding = 40;
  
  let svg = `<svg width="${width}" height="${height}" style="width: 100%; height: auto;">`;
  
  // Y-axis
  svg += `<line x1="${padding}" y1="20" x2="${padding}" y2="${height - padding}" stroke="#ccc" stroke-width="2"/>`;
  
  // X-axis
  svg += `<line x1="${padding}" y1="${height - padding}" x2="${width}" y2="${height - padding}" stroke="#ccc" stroke-width="2"/>`;
  
  // Bars
  data.forEach((value, index) => {
    const barHeight = (value / max) * (height - padding - 20);
    const x = padding + index * barWidth + barWidth * 0.2;
    const y = height - padding - barHeight;
    
    svg += `<rect x="${x}" y="${y}" width="${barWidth * 0.6}" height="${barHeight}" fill="#2E7D32" opacity="0.8" rx="4"/>`;
    
    // Label
    svg += `<text x="${x + barWidth * 0.3}" y="${height - padding + 20}" text-anchor="middle" font-size="12" fill="#666">${labels[index]}</text>`;
    
    // Value
    svg += `<text x="${x + barWidth * 0.3}" y="${y - 5}" text-anchor="middle" font-size="11" font-weight="bold" fill="#2E7D32">${value}</text>`;
  });
  
  svg += `</svg>`;
  container.innerHTML = svg;
}

// Line Chart (SVG)
function createLineChart(canvasId, labels, data, maxValue = null) {
  const container = document.getElementById(canvasId);
  if (!container) return;
  
  const max = maxValue || Math.max(...data);
  const width = container.offsetWidth;
  const height = 300;
  const padding = 40;
  const pointSpacing = (width - padding * 2) / (labels.length - 1);
  
  let svg = `<svg width="${width}" height="${height}" style="width: 100%; height: auto;">`;
  
  // Grid lines
  for (let i = 0; i <= 5; i++) {
    const y = padding + (i * (height - padding * 2) / 5);
    svg += `<line x1="${padding}" y1="${y}" x2="${width - padding}" y2="${y}" stroke="#eee" stroke-width="1" stroke-dasharray="4"/>`;
  }
  
  // Axes
  svg += `<line x1="${padding}" y1="20" x2="${padding}" y2="${height - padding}" stroke="#999" stroke-width="2"/>`;
  svg += `<line x1="${padding}" y1="${height - padding}" x2="${width}" y2="${height - padding}" stroke="#999" stroke-width="2"/>`;
  
  // Line path
  let pathData = '';
  data.forEach((value, index) => {
    const x = padding + index * pointSpacing;
    const y = height - padding - (value / max) * (height - padding * 2);
    pathData += `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
  });
  
  svg += `<path d="${pathData}" fill="none" stroke="#2E7D32" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`;
  
  // Points
  data.forEach((value, index) => {
    const x = padding + index * pointSpacing;
    const y = height - padding - (value / max) * (height - padding * 2);
    svg += `<circle cx="${x}" cy="${y}" r="5" fill="#F9A825" stroke="white" stroke-width="2"/>`;
  });
  
  // Labels
  labels.forEach((label, index) => {
    const x = padding + index * pointSpacing;
    svg += `<text x="${x}" y="${height - padding + 20}" text-anchor="middle" font-size="12" fill="#666">${label}</text>`;
  });
  
  svg += `</svg>`;
  container.innerHTML = svg;
}

// Doughnut Chart (SVG)
function createDoughnutChart(canvasId, labels, data, colors = null) {
  const container = document.getElementById(canvasId);
  if (!container) return;
  
  const total = data.reduce((a, b) => a + b, 0);
  const defaultColors = ['#2E7D32', '#43A047', '#F9A825', '#FF9500', '#E53935', '#1E88E5'];
  const chartColors = colors || defaultColors;
  
  const width = 400;
  const height = 300;
  const centerX = width / 2;
  const centerY = height / 2;
  const outerRadius = 80;
  const innerRadius = 50;
  
  let svg = `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" style="max-width: 100%; height: auto;">`;
  
  let currentAngle = -Math.PI / 2;
  
  data.forEach((value, index) => {
    const sliceAngle = (value / total) * 2 * Math.PI;
    const startAngle = currentAngle;
    const endAngle = currentAngle + sliceAngle;
    
    const x1 = centerX + outerRadius * Math.cos(startAngle);
    const y1 = centerY + outerRadius * Math.sin(startAngle);
    const x2 = centerX + outerRadius * Math.cos(endAngle);
    const y2 = centerY + outerRadius * Math.sin(endAngle);
    
    const ix1 = centerX + innerRadius * Math.cos(startAngle);
    const iy1 = centerY + innerRadius * Math.sin(startAngle);
    const ix2 = centerX + innerRadius * Math.cos(endAngle);
    const iy2 = centerY + innerRadius * Math.sin(endAngle);
    
    const largeArc = sliceAngle > Math.PI ? 1 : 0;
    
    const path = `M ${x1} ${y1} A ${outerRadius} ${outerRadius} 0 ${largeArc} 1 ${x2} ${y2} L ${ix2} ${iy2} A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${ix1} ${iy1} Z`;
    
    svg += `<path d="${path}" fill="${chartColors[index % chartColors.length]}" opacity="0.8" stroke="white" stroke-width="2"/>`;
    
    // Label
    const labelAngle = startAngle + sliceAngle / 2;
    const labelRadius = (outerRadius + innerRadius) / 2;
    const lx = centerX + labelRadius * Math.cos(labelAngle);
    const ly = centerY + labelRadius * Math.sin(labelAngle);
    const percentage = ((value / total) * 100).toFixed(0);
    
    svg += `<text x="${lx}" y="${ly}" text-anchor="middle" dominant-baseline="middle" font-size="12" font-weight="bold" fill="white">${percentage}%</text>`;
    
    currentAngle = endAngle;
  });
  
  svg += `</svg>`;
  
  // Add legend
  let legend = '<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-top: 1rem;">';
  labels.forEach((label, index) => {
    const percentage = ((data[index] / total) * 100).toFixed(1);
    legend += `<div style="display: flex; align-items: center; gap: 0.5rem;">
      <div style="width: 16px; height: 16px; background: ${chartColors[index % chartColors.length]}; border-radius: 2px;"></div>
      <span style="font-size: 0.9rem;">${label} (${percentage}%)</span>
    </div>`;
  });
  legend += '</div>';
  
  container.innerHTML = svg + legend;
}

// Area Chart (SVG)
function createAreaChart(canvasId, labels, data, maxValue = null) {
  const container = document.getElementById(canvasId);
  if (!container) return;
  
  const max = maxValue || Math.max(...data);
  const width = container.offsetWidth;
  const height = 300;
  const padding = 40;
  const pointSpacing = (width - padding * 2) / (labels.length - 1);
  
  let svg = `<svg width="${width}" height="${height}" style="width: 100%; height: auto;">`;
  
  // Grid
  for (let i = 0; i <= 5; i++) {
    const y = padding + (i * (height - padding * 2) / 5);
    svg += `<line x1="${padding}" y1="${y}" x2="${width - padding}" y2="${y}" stroke="#eee" stroke-width="1"/>`;
  }
  
  // Area path
  let pathData = `M ${padding} ${height - padding}`;
  data.forEach((value, index) => {
    const x = padding + index * pointSpacing;
    const y = height - padding - (value / max) * (height - padding * 2);
    pathData += ` L ${x} ${y}`;
  });
  pathData += ` L ${width - padding} ${height - padding} Z`;
  
  svg += `<defs>
    <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" style="stop-color:#43A047;stop-opacity:0.3" />
      <stop offset="100%" style="stop-color:#43A047;stop-opacity:0" />
    </linearGradient>
  </defs>`;
  
  svg += `<path d="${pathData}" fill="url(#areaGradient)"/>`;
  
  // Line
  pathData = '';
  data.forEach((value, index) => {
    const x = padding + index * pointSpacing;
    const y = height - padding - (value / max) * (height - padding * 2);
    pathData += `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
  });
  
  svg += `<path d="${pathData}" fill="none" stroke="#2E7D32" stroke-width="2"/>`;
  
  // Axes
  svg += `<line x1="${padding}" y1="20" x2="${padding}" y2="${height - padding}" stroke="#999" stroke-width="2"/>`;
  svg += `<line x1="${padding}" y1="${height - padding}" x2="${width}" y2="${height - padding}" stroke="#999" stroke-width="2"/>`;
  
  // Labels
  labels.forEach((label, index) => {
    const x = padding + index * pointSpacing;
    svg += `<text x="${x}" y="${height - padding + 20}" text-anchor="middle" font-size="12" fill="#666">${label}</text>`;
  });
  
  svg += `</svg>`;
  container.innerHTML = svg;
}

// Radar Chart (SVG)
function createRadarChart(canvasId, labels, datasets) {
  const container = document.getElementById(canvasId);
  if (!container) return;
  
  const numPoints = labels.length;
  const width = 400;
  const height = 400;
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = 120;
  
  let svg = `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" style="max-width: 100%; height: auto;">`;
  
  // Grid circles
  for (let i = 1; i <= 5; i++) {
    const r = (radius / 5) * i;
    svg += `<circle cx="${centerX}" cy="${centerY}" r="${r}" fill="none" stroke="#ddd" stroke-width="1"/>`;
  }
  
  // Axes
  for (let i = 0; i < numPoints; i++) {
    const angle = (i / numPoints) * 2 * Math.PI - Math.PI / 2;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    svg += `<line x1="${centerX}" y1="${centerY}" x2="${x}" y2="${y}" stroke="#ddd" stroke-width="1"/>`;
  }
  
  // Data points and polygons
  const colors = ['#2E7D32', '#F9A825', '#E53935'];
  datasets.forEach((dataset, dsIndex) => {
    let pathData = '';
    
    dataset.data.forEach((value, index) => {
      const normalizedValue = value / 100;
      const angle = (index / numPoints) * 2 * Math.PI - Math.PI / 2;
      const x = centerX + (radius * normalizedValue) * Math.cos(angle);
      const y = centerY + (radius * normalizedValue) * Math.sin(angle);
      pathData += `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
    });
    pathData += ' Z';
    
    svg += `<path d="${pathData}" fill="${colors[dsIndex % colors.length]}" opacity="0.3" stroke="${colors[dsIndex % colors.length]}" stroke-width="2"/>`;
  });
  
  // Labels
  for (let i = 0; i < numPoints; i++) {
    const angle = (i / numPoints) * 2 * Math.PI - Math.PI / 2;
    const x = centerX + (radius + 30) * Math.cos(angle);
    const y = centerY + (radius + 30) * Math.sin(angle);
    svg += `<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle" font-size="12" fill="#333">${labels[i]}</text>`;
  }
  
  svg += `</svg>`;
  container.innerHTML = svg;
}

// Scatter Plot (SVG)
function createScatterPlot(canvasId, data, labels) {
  const container = document.getElementById(canvasId);
  if (!container) return;
  
  const padding = 40;
  const width = container.offsetWidth || 500;
  const height = 350;
  
  const xValues = data.map(d => d.x);
  const yValues = data.map(d => d.y);
  const maxX = Math.max(...xValues);
  const maxY = Math.max(...yValues);
  
  let svg = `<svg width="${width}" height="${height}" style="width: 100%; height: auto;">`;
  
  // Grid
  for (let i = 0; i <= 5; i++) {
    const y = padding + (i * (height - padding * 2) / 5);
    svg += `<line x1="${padding}" y1="${y}" x2="${width - padding}" y2="${y}" stroke="#eee" stroke-width="1"/>`;
    
    const x = padding + (i * (width - padding * 2) / 5);
    svg += `<line x1="${x}" y1="${padding}" x2="${x}" y2="${height - padding}" stroke="#eee" stroke-width="1"/>`;
  }
  
  // Axes
  svg += `<line x1="${padding}" y1="${padding}" x2="${padding}" y2="${height - padding}" stroke="#999" stroke-width="2"/>`;
  svg += `<line x1="${padding}" y1="${height - padding}" x2="${width}" y2="${height - padding}" stroke="#999" stroke-width="2"/>`;
  
  // Data points
  data.forEach((point, index) => {
    const x = padding + (point.x / maxX) * (width - padding * 2);
    const y = height - padding - (point.y / maxY) * (height - padding * 2);
    
    svg += `<circle cx="${x}" cy="${y}" r="6" fill="#2E7D32" opacity="0.7" stroke="white" stroke-width="2"/>`;
  });
  
  svg += `</svg>`;
  container.innerHTML = svg;
}

// Initialize theme on load
document.addEventListener('DOMContentLoaded', initTheme);
