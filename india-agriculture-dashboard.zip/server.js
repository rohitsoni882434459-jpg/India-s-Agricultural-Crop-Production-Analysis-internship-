const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;

const server = http.createServer((req, res) => {
  // Handle root path
  if (req.url === '/') {
    req.url = '/index.html';
  }

  // Set default file to index.html for directory requests
  if (req.url.endsWith('/')) {
    req.url += 'index.html';
  }

  // Get the file path
  let filePath = path.join(__dirname, req.url);

  // Get file extension
  const extname = path.extname(filePath).toLowerCase();

  // Set content type
  const contentTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
  };

  const contentType = contentTypes[extname] || 'application/octet-stream';

  // Read and serve the file
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 - File Not Found</h1>', 'utf-8');
      } else {
        res.writeHead(500);
        res.end('Server error: ' + err.code, 'utf-8');
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content, 'utf-8');
    }
  });
});

server.listen(PORT, () => {
  console.log(`Agriculture Analytics Dashboard running at http://localhost:${PORT}`);
  console.log(`Press Ctrl+C to stop the server`);
});
